import React from 'react'

export const Movies = () => {
  return (
    <div>
      Movies page
    </div>
  )
}
