import React from 'react'

export const Trendings = () => {
  return (
    <div>
      Trendings page
    </div>
  )
}

