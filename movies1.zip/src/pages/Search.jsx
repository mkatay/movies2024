import React from 'react'

export const Search = () => {
  return (
    <div>
      search...
    </div>
  )
}
