import React from 'react'
import './NotFound.css'

export const NotFound = () => {
  return (
    <div className="notfound-container">
    <div className="notfound">
      <h3>Page NOT found</h3>
      <h6>404</h6>
    </div>
  </div>
          
      );
    }
    
